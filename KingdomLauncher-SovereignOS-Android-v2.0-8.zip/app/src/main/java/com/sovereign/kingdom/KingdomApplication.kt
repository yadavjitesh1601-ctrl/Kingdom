package com.sovereign.kingdom

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class KingdomApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "sovereign_guardian_channel",
                "Sovereign OS Guardian Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Runs local firewall, Dynamic Notch Interceptor, and Sludge Decay services."
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}