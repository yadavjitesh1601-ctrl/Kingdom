package com.sovereign.kingdom.service

import android.net.VpnService
import android.os.ParcelFileDescriptor

/**
 * Local Dead-End VPN Distraction Firewall (NetGuard Zero-Remote Architecture)
 * Sinks blacklisted packets to unresolved 10.1.1.1 dummy interface while whitelisted tools retain 100% speed.
 */
class LocalFirewallVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null
    private val blacklistedPackages = mutableSetOf(
        "com.zhiliaoapp.musically",
        "com.instagram.android",
        "com.reddit.frontpage",
        "com.google.android.youtube",
        "com.twitter.android"
    )

    fun startFirewall() {
        val builder = Builder()
            .setSession("SovereignImperialFirewall")
            .addAddress("10.1.1.1", 24)
            .addDnsServer("1.1.1.1")

        for (pkg in blacklistedPackages) {
            try {
                builder.addPackageToDisallowedApp(pkg)
            } catch (_: Exception) {}
        }

        vpnInterface = builder.establish()
    }

    override fun onDestroy() {
        vpnInterface?.close()
        super.onDestroy()
    }
}