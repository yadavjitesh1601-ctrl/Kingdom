package com.sovereign.kingdom.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sovereign.kingdom.ui.theme.*

@Composable
fun KingdomDashboardScreen() {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Imperial Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SOVEREIGN OS",
                color = ImperialGold,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Surface(
                color = ImperialDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ImperialBorder)
            ) {
                Text(
                    text = "● 98% BANDWIDTH",
                    color = ToxicGreen,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        // Daily AI Decree Hero Card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            color = ImperialCardBg,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, ImperialGold.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SOVEREIGN AI DECREE",
                    color = ImperialGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "\"The throne is already claimed. Let algorithmic distractions perish outside the city gates.\"",
                    color = Color.White,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "MAGISTRATE: CHANCELLOR AURELIUS",
                    color = SlateSubtext,
                    fontSize = 9.sp,
                    letterSpacing = 1.sp
                )
            }
        }

        // 3-Card Telemetry Array
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TelemetryCard(modifier = Modifier.weight(1f), label = "DISCIPLINE", value = "98%", color = ToxicGreen)
            TelemetryCard(modifier = Modifier.weight(1f), label = "INTERCEPTS", value = "14", color = ImperialGold)
            TelemetryCard(modifier = Modifier.weight(1f), label = "CLEAN TIME", value = "6.4h", color = GoldBright)
        }

        // Whitelisted Essential Tools Grid
        Text(
            text = "SOVEREIGN TOOLS (100% UNRESTRICTED)",
            color = SlateSubtext,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AppTile(modifier = Modifier.weight(1f), name = "Phone", subtitle = "Voice")
            AppTile(modifier = Modifier.weight(1f), name = "Signal", subtitle = "Comms")
            AppTile(modifier = Modifier.weight(1f), name = "Terminal", subtitle = "Code")
            AppTile(modifier = Modifier.weight(1f), name = "Docs", subtitle = "Deep Work")
        }

        // Sealed Distraction Gates
        Text(
            text = "SEALED GATES (LOCAL VPN SINKHOLE)",
            color = FlameCrimson,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AppTile(modifier = Modifier.weight(1f), name = "TikTok", subtitle = "SUNK 10.1.1.1", isSealed = true)
            AppTile(modifier = Modifier.weight(1f), name = "Instagram", subtitle = "SUNK 10.1.1.1", isSealed = true)
            AppTile(modifier = Modifier.weight(1f), name = "YouTube", subtitle = "SUNK 10.1.1.1", isSealed = true)
            AppTile(modifier = Modifier.weight(1f), name = "Reddit", subtitle = "SUNK 10.1.1.1", isSealed = true)
        }
    }
}

@Composable
fun TelemetryCard(modifier: Modifier = Modifier, label: String, value: String, color: Color) {
    Surface(
        modifier = modifier,
        color = ImperialDark,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, ImperialBorder)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = label, color = SlateSubtext, fontSize = 8.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp)
        }
    }
}

@Composable
fun AppTile(modifier: Modifier = Modifier, name: String, subtitle: String, isSealed: Boolean = false) {
    Surface(
        modifier = modifier,
        color = if (isSealed) Color(0xFF160B0D) else ImperialDark,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSealed) FlameCrimson.copy(alpha = 0.4f) else ImperialBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = name,
                color = if (isSealed) FlameCrimson else Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = if (isSealed) FlameCrimson.copy(alpha = 0.7f) else SlateSubtext,
                fontSize = 8.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}