package com.sovereign.kingdom.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = ImperialGold,
    secondary = GoldBright,
    background = ObsidianBlack,
    surface = ImperialDark,
    onPrimary = ObsidianBlack,
    onSecondary = ObsidianBlack,
    onBackground = ImperialGold,
    onSurface = ImperialGold,
)

@Composable
fun KingdomLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}