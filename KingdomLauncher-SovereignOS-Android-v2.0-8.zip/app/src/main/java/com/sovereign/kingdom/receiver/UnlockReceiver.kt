package com.sovereign.kingdom.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class UnlockReceiver : BroadcastReceiver() {
    companion object {
        private var unlockCountInWindow = 0
        private var windowStartTime = System.currentTimeMillis()
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_USER_PRESENT -> {
                val now = System.currentTimeMillis()
                if (now - windowStartTime > 10 * 60 * 1000) {
                    unlockCountInWindow = 1
                    windowStartTime = now
                } else {
                    unlockCountInWindow++
                    if (unlockCountInWindow >= 3) {
                        Log.w("SovereignOS", "Urge spike detected! 3 unlocks within 10 minutes.")
                    }
                }
            }
            Intent.ACTION_SCREEN_OFF -> {
                // Screen turned off - trigger 0-order linear sludge decay
            }
        }
    }
}