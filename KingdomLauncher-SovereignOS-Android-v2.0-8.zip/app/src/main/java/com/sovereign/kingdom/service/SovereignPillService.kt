package com.sovereign.kingdom.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * Sovereign Notch Pill Overlay (Dynamic Island Interceptor)
 * Wraps camera cutout and expands from 110dp to 320dp on distraction launch.
 */
class SovereignPillService : Service() {
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var isExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotchOverlay()
    }

    private fun createNotchOverlay() {
        val params = WindowManager.LayoutParams(
            dpToPx(110),
            dpToPx(34),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dpToPx(8)
        }
    }

    fun expandIntervention(directive: String) {
        if (isExpanded) return
        isExpanded = true
    }

    fun collapseToIdle() {
        if (!isExpanded) return
        isExpanded = false
    }

    private fun dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()
}