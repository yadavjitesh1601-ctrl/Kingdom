package com.sovereign.kingdom.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBlack = Color(0xFF040508)
val ImperialDark = Color(0xFF0D0F17)
val ImperialCardBg = Color(0xFF141824)
val ImperialBorder = Color(0xFF1E2433)
val ImperialGold = Color(0xFFD4AF37)
val GoldBright = Color(0xFFF3C748)
val SludgeOlive = Color(0xFF333520)
val ToxicGreen = Color(0xFF10B981)
val FlameCrimson = Color(0xFFEF4444)
val SlateSubtext = Color(0xFF94A3B8)