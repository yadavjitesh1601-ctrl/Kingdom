# Proguard rules for Sovereign OS Launcher
-keep class com.sovereign.kingdom.** { *; }